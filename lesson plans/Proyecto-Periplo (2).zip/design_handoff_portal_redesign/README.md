# Handoff: Rediseño del Portal del Alumno (dirección "mobile-game")

## Resumen / Overview

Este paquete contiene el **rediseño visual completo** del Portal del Alumno de Periplo,
en una dirección de **juego móvil** (brillante, chunky, dopamínico — al estilo de apps
tipo Duolingo / Monopoly GO), reemplazando el look anterior (oscuro, cálido, "de reposo").

El objetivo del rediseño: que el alumno **entienda de inmediato qué es un botón y qué
tocar**, con jerarquía clarísima, racha como héroe, y feedback de juego (botones 3D
presionables, progreso visible, insignias).

**Tarea para Claude Code:** recrear este diseño dentro del archivo de producción
existente `student_portal.html` (React vía Babel + Firebase/Firestore), **sustituyendo
la piel anterior pero conservando toda la lógica de datos, autenticación y Firebase que
ya funciona.** No es cambiar la app: es re-vestirla.

---

## ⚠️ Sobre los archivos de diseño (LÉEME PRIMERO)

Los archivos en `diseno/` son **referencias de diseño hechas en HTML/React** — prototipos
que muestran el look y el comportamiento buscado. **No son código de producción para
copiar tal cual.** Diferencias clave con producción:

| | Diseño (este bundle) | Producción (`student_portal.html`) |
|---|---|---|
| Datos | **Demo hardcodeado** (`DEMO`, `SOLO_DEMO`, arrays) | Objeto `student` real desde Firestore (`window.PERIPLO`) |
| Estructura | Partido en varios `.jsx` con `window.*` | Un solo HTML con módulos ES + import maps |
| React | UMD + Babel standalone (`window.React`) | Igual (Babel in-browser) — **compatible** |
| Auth/DB | Ninguna | Firebase Auth + `onSnapshot` (ya implementado) |
| Tema | `localStorage` `periplo-redesign-theme` | A definir (ver §Tema) |

**La fuente de verdad del comportamiento de datos es `student_portal.html`.** La fuente de
verdad del **look** es este bundle. Tu trabajo es fusionarlos: tomar los componentes,
estilos y tokens de aquí y conectarlos a `window.PERIPLO` / Firebase de allá.

---

## Fidelidad: ALTA (hi-fi)

Mockups pixel-perfect con colores, tipografía, espaciados e interacciones finales.
Recréalos con fidelidad. Todos los valores exactos están en §Design Tokens y en los `.jsx`.

---

## Cómo correr el diseño para verlo

Abre `diseno/Portal Rediseño.html` en un navegador (necesita internet para las fuentes
de Google y React desde unpkg). Es un teléfono navegable:

- **Barra inferior** (Inicio · Solo · Agenda · Más) cambia de pantalla.
- En **Inicio**: el tile "Solo" lleva a Solo; la tarjeta de próxima clase lleva a Agenda.
- En **Solo**: toca un mundo desbloqueado → ves sus 6 misiones → toca una → hoja de detalle.
- En **Más → Ajustes → Tema**: toggle ☀️/🌙 repinta toda la app (Día/Noche).
- El estado (tab + tema) persiste en `localStorage`.

---

## Decisiones de diseño ya tomadas (no re-litigar)

1. **Se quedan los DOS temas** (Día/crema y Noche/vibrante). El usuario elige; el switch
   vive en **Más → Ajustes → Tema** como un toggle deslizante (no un acordeón).
2. **Modo Solo = Constelación** (mapa espacial brillante). Se descartó la idea "Sendero".
   Solo **siempre** se ve en su fondo espacial oscuro, sin importar el tema global.
3. **Racha 🔥 es el héroe** de Inicio (número gigante + tira de 7 días).
4. **Botones 3D presionables** (borde inferior duro `box-shadow: 0 5px 0 <edge>`, se hunden
   con `:active`). Es EL patrón central — "que se vea que es botón".
5. **Tipografía:** Fredoka (títulos/labels/botones) + Nunito (cuerpo). Se reemplaza Syne.

---

## Pantallas / Screens

Las 4 pantallas comparten: padding superior `54px` (status bar), padding inferior `~96px`
(para no quedar bajo la barra), y la `BottomNav` flotante (`position:absolute; bottom:0`).
Cada pantalla recibe el tema `t` (objeto de tokens, ver §Tokens).

### 1. Inicio (`home-game.jsx` → `HomeGame`)
**Propósito:** dashboard diario; qué jugar hoy + racha + accesos.
Orden vertical de bloques:
1. **Top bar** — avatar (círculo con gradiente amarillo→naranja, `box-shadow 0 3px 0 edge`),
   "¡Hola de nuevo!" + nombre, y "moneda" de XP a la derecha (pill blanca con ⭐).
2. **Hero de Racha** — tarjeta con `heroGrad` (gradiente naranja→rosa), 🔥 gigante con el
   número encima, "X días seguidos", y **tira semanal** de 7 celdas (hechas = 🔥 sobre
   blanco; hoy = borde blanco + "?"; futuras = translúcidas). Borde inferior 3D `heroEdge`.
3. **Misión de hoy** — tarjeta blanca; eyebrow "◆ Misión de hoy" + chip "Misión 4/6";
   ícono 🚀 (gradiente azul→morado), nombre del módulo + subtítulo; **barra de progreso**
   (gradiente verde→azul) + %; **botón 3D verde "Continuar mi viaje"** (CTA primario).
4. **Explora** — 3 tiles (Patio 🎮 amarillo, Solo 🚀 morado, Recursos 📚 azul). Cada tile
   = ícono cuadrado con gradiente + `0 4px 0 edge`, título Fredoka, subtítulo del color.
5. **Alerta Taller** — fila rosada (`#FFF0F4` claro / translúcido en oscuro), 🛠️ con badge
   numérico (= `weakCount`), texto, botón 3D rosa "Pulir".
6. **Próxima clase** — fila blanca con bloque de fecha (azul), tema, "X/3 clases esta
   semana", chevron. Lleva a Agenda.

### 2. Solo (`solo-game.jsx` → `SoloGame`, prop `style="constelacion"`)
**Propósito:** mapa de progreso del nivel (galaxia) con mundos y misiones.
- **Header:** "MODO SOLO" + "Constelación <Nivel>" + pill de nivel (🌱 Basic).
- **Mapa Constelación** (`MapConstelacion`): fondo espacial oscuro radial, polvo de
  estrellas, mundos como **estrellas** posicionadas en zig-zag (xFactors `[.24,.7,.4,.76]`),
  conectadas por líneas punteadas; la parte recorrida se ilumina en azul. Estados:
  - **done** = estrella verde con ✓.
  - **active** = estrella azul más grande con número, halo brillante, avatar flotando arriba (`.bob`).
  - **locked** = círculo tenue con 🔒, borde punteado.
  - Etiquetas de **módulo** (B1/B2/B-MIX) al inicio de cada bloque.
- **Tap en un mundo desbloqueado** → `WorldView`:
  - Botón "Volver al mapa", header del mundo (gradiente morado→azul, % logrado, "X/6 misiones").
  - **Lista de 6 misiones** con spine numerado (✓ done / número active / 🔒 locked), cada una
    tarjeta con emoji, nombre, estado ("✓ Superada" / "Aquí vas · ¡juega!" / "Bloqueada").
  - CTA inferior con la misión activa, o estado "¡Mundo conquistado!".
- **Tap en una misión** → `MissionSheet` (bottom sheet animado `.sheet-up`): emoji grande,
  "Misión N de 6", descripción, botón 3D "Empezar / Volver a jugar", o candado si locked.

### 3. Agenda (`agenda-mas.jsx` → `AgendaGame`)
**Propósito:** clases en vivo de la semana.
1. **Título** "Tu agenda" / "Esta semana".
2. **Meta semanal** — tarjeta gradiente azul→morado: "Meta semanal", número grande
   `usados / total`, chip "¡Vas bien! 🎯", barra segmentada (un segmento por clase del plan),
   botón 3D blanco "＋ Agendar una clase".
3. **Semana en chips** — 7 celdas L-D: hecha = verde ✓, con clase = azul 📚, hoy = borde naranja.
4. **Próximas clases** (`ClassCard`) — fecha en bloque de color, badge "● Próxima" en la
   más cercana (borde verde), tema, hora · teacher, botón 3D "Entrar".
5. **Clases tomadas** — filas tenues con ✓ verde.

### 4. Más (`agenda-mas.jsx` → `MasGame`)
**Propósito:** perfil, accesos secundarios, ajustes.
1. **Perfil** — avatar, nombre, pills de arquetipo (Dreamer 🌱) y racha (🔥 N).
2. **Tu aprendizaje** — 4 filas: Mi Progreso 🎯, Mi Taller 🛠️ (badge = weakCount),
   Patio de Juegos 🎮, Recursos del Viajero 📚.
3. **Ajustes** — bloque de filas iguales: **Tema** (con `ThemeToggle` ☀️/🌙 a la derecha en
   vez de chevron), Notificaciones 🔔, Idioma 🌐, Ayuda ❓.
4. Botón "Cerrar sesión" (outline rosa).

---

## 🔌 Mapeo de datos: DEMO → Firebase real (CRÍTICO)

El diseño usa objetos `DEMO` / `SOLO_DEMO`. Conéctalos a `window.PERIPLO` (que ya se
construye desde Firestore en `student_portal.html`, ~línea 1888). Equivalencias:

| Diseño (demo) | Producción (real) | Notas |
|---|---|---|
| `DEMO.firstName` | `PERIPLO.student.firstName` | ya existe (`name.split(' ')[0]`) |
| `DEMO.name` | `PERIPLO.student.name` | |
| `DEMO.avatar.emoji` | `PERIPLO.student.avatar.emoji` | hay también `avatar.color` — úsalo para tintar el aro del avatar |
| `DEMO.streak` | `PERIPLO.student.streak` | número entero |
| `DEMO.xp` | `PERIPLO.student.xp` | |
| `DEMO.level` | `PERIPLO.student.level` | `'basic' \| 'advanced' \| 'pro'` → define la galaxia/título de Solo |
| `DEMO.module` / `moduleSub` | `PERIPLO.module.name` (`student.currentModule`) | el subtítulo puede derivarse del catálogo de módulos existente |
| `DEMO.moduleProgress` | derivar de `student.soloProgress[currentWorld].done / 6` | 0..1 |
| `DEMO.missionN` / `missionTotal` | `soloProgress[world].done` y `6` | |
| `DEMO.weakCount` | `PERIPLO.weakCount` | ya calculado (remediation high+mid) |
| `DEMO.classesPerWeek` | `PERIPLO.student.plan.classesPerWeek` | default 3 |
| `DEMO.classesTaken` | `PERIPLO.student.plan.usedThisWeek` | |
| `DEMO.lore` / `arch` | `PERIPLO.lore` / `PERIPLO.arch` | para pills de perfil (Dreamer, Explorer…) |
| `DEMO.week[]` (racha) | derivar de historial de actividad si existe; si no, de `plan.usedThisWeek` | ver nota racha |
| `DEMO.nextClass` / Agenda | colección Firestore `artifacts/periplo-app-v1/schedule` vía `onSnapshot` (ya cargada, ~línea 993) filtrando por nombre del alumno | la lógica de match ya existe |

### Solo — mundos y misiones (mapeo directo, casi 1:1)
- En diseño, `WORLDS` es un array fijo con `{id, week, title, sub, module}`. En producción
  ya existe `MODULE_ORDER[level]`, `GALAXIES`, y `buildSoloMissions(worldId, student)`.
  **Usa los reales.** El catálogo de mundos del rediseño es ilustrativo; respeta el de prod.
- El estado de cada misión es **idéntico** en ambos:
  ```js
  status = i < done ? 'done' : i === done ? 'active' : 'locked'   // done = soloProgress[world].done
  ```
  El diseño usa `state`, prod usa `status` — solo renombra al integrar.
- El estado de cada **mundo** (done/active/locked) en el diseño se calcula por `week` vs
  `currentWeek`. En prod, deríva­lo de `soloProgress` (mundos con done≥6 = completados, el
  primero incompleto = activo, los siguientes = bloqueados) — coherente con `buildSolo*` existente.

### Nota sobre la tira de racha semanal (Inicio)
El diseño dibuja 7 días con 🔥 en los completados. Si en Firestore no hay un registro
diario de actividad, aproxima: marca como "hecho" hasta `hoy` según `streak` acotado a la
semana, o deja la tira como visual de `usedThisWeek`. Si existe un campo de historial,
úsalo. **No inventes un backend nuevo** — adapta a lo que ya guarda el alumno.

---

## Interacciones y comportamiento

- **Navegación de tabs:** estado `tab` (`home|solo|agenda|mas`); la `BottomNav` lo cambia.
  En prod ya hay navegación equivalente — reúsala, solo intercambia el chrome visual.
- **Transición entre tabs:** clase `.fade-tab` (fadeTab .26s) al montar cada pantalla.
- **Solo:** `setWorld` abre `WorldView` (`.zoom-in`), `setSheet` abre `MissionSheet`
  (`.sheet-up`, .32s cubic-bezier). Cerrar tocando el backdrop.
- **Botones 3D:** hover `brightness(1.04)`; `:active` baja `translateY(5px)` y colapsa la
  sombra inferior (efecto de presión). Clases `.g-btn`, `.g-tile`, `.g-node`.
- **Avatar activo en el mapa:** flota con `@keyframes bob` (2.4s, infinito).
- **Toggle de tema:** `ThemeToggle` — un clic alterna `light`↔`dark`; el knob se desliza
  con `cubic-bezier(.34,1.56,.64,1)`; repinta TODA la app (el tema es estado global).
- **Reduced motion / captura:** las animaciones son de entrada (no bloquean contenido);
  el estado final visible no depende de ellas.

## Estado / State

| Estado | Dónde | Persistencia |
|---|---|---|
| `tab` | shell (`Shell` en el HTML) | `localStorage['periplo-redesign-tab']` — renombra a tu key |
| `theme` | shell, propaga `t = THEMES[theme]` a todo | `localStorage['periplo-redesign-theme']` |
| `world` / `sheet` | dentro de `SoloGame` | efímero |

El **tema** debe ser global: un proveedor/estado en la raíz que reparte el objeto de
tokens `t`. Cada componente ya está escrito para recibir `t` y leer de ahí (sin colores
hardcodeados fuera de los tokens). Para integrarlo en prod, decide si guardas la
preferencia en `localStorage` o en el doc del alumno en Firestore.

---

## Design Tokens

Definidos en `home-game.jsx` → `THEMES.light` y `THEMES.dark`. Resumen:

### Tema Día (light)
- Fondo: `radial-gradient(120% 80% at 50% -10%, #FFF4DD 0%, #FCEAC9 55%, #F6DEB4 100%)`
- Tinta: `#33303B` / secundaria `#8A8295` / tenue `#B6AEBC`
- Tarjeta: `#FFFFFF`, sub `#FBF4EA`, borde 3D `#EAD9BE`, línea `rgba(50,40,30,.08)`
- Hero: `linear-gradient(135deg,#FF8A3D,#FF5C6E 60%,#FF4D8D)`, borde `#D8431A`

### Tema Noche (dark)
- Fondo: `radial-gradient(120% 80% at 50% -10%, #2A2150 0%, #1B1638 50%, #120F26 100%)`
- Tinta: `#FBF7FF` / secundaria `#A79FC9` / tenue `#6E668F`
- Tarjeta: `#2A2350`, sub `#221C44`, borde 3D `#15102E`

### Acentos (cada uno con cara `f` + borde 3D `e`), valores Día / Noche
- 🔥 flame: `#FF6A3D/#D8431A` · `#FF7A45/#C9461C`
- 🟢 green:  `#22B26A/#178A4F` · `#2ED27E/#19914F`
- 🔵 blue:   `#3B9BF0/#1F73C9` · `#54A9FF/#2E72CC`
- 🟡 yellow: `#FFC22E/#E29400` · `#FFCE3D/#D89C00`
- 🟣 purple: `#8B6CF0/#6747D2` · `#A98BFF/#7553E0`
- 🩷 pink:   `#FF5C8A/#DB335F` · `#FF6E9E/#D43E72`

### Tipografía
- **Fredoka** (400–700): títulos, labels (uppercase, letter-spacing .13em), botones, números.
- **Nunito** (400–800): cuerpo, subtítulos, descripciones.
- Import: `fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600;700&family=Nunito:wght@400;600;700;800`

### Radios / sombras
- Radios: tiles 18–22, tarjetas 24–28, hero 28, botones 16–20, pills 999.
- Sombra 3D de botón: `0 5px 0 var(--edge), 0 8px 16px rgba(0,0,0,.16)`; `:active` → `0 0 0 var(--edge)` + `translateY(5px)`.
- Sombra de tarjeta: `0 4px 0 <cardEdge>, <softShadow>`.

---

## Assets
- **Sin imágenes externas.** Todo es CSS + emoji + SVG inline (iconos en `IPATHS`/`SPATHS`
  dentro de los `.jsx`). Los emoji (🦊🔥🚀🎮📚🛠️🌱🗺️) hacen de "ilustración".
- Las **fuentes** vienen de Google Fonts. Si prod debe correr offline, auto-aloja Fredoka y Nunito.
- React/Babel: en el diseño vienen de unpkg con `integrity`; prod ya usa Babel in-browser.

## Capturas de referencia (carpeta `capturas/`)
Imágenes literales de cada pantalla, como meta visual a igualar:
- `1-inicio-dia.png` — Inicio, tema Día
- `2-solo-constelacion.png` — Solo: mapa Constelación (siempre en modo espacial)
- `3-solo-mundo.png` — Solo: vista de mundo con las 6 misiones
- `4-solo-mision.png` — Solo: hoja de detalle de misión (bottom sheet)
- `5-agenda-dia.png` — Agenda, tema Día
- `6-mas-dia.png` — Más, tema Día (con el toggle de Tema)
- `7-inicio-noche.png` — Inicio, tema Noche
- `8-agenda-noche.png` — Agenda, tema Noche
- `9-mas-noche.png` — Más, tema Noche

## Archivos de este bundle (en `diseno/`)
- `Portal Rediseño.html` — shell navegable (estado de tab/tema + scaling del teléfono). **Empieza aquí.**
- `ios-frame.jsx` — bezel del teléfono (solo para la maqueta; NO va a producción).
- `home-game.jsx` — `HomeGame`, `THEMES` (tokens), `Btn3D`, `Icon`, `DEMO`.
- `solo-game.jsx` — `SoloGame`, `MapConstelacion`, `WorldView`, `MissionSheet`, `SOLO_DEMO`, `WORLDS`, `MISSIONS`.
- `agenda-mas.jsx` — `AgendaGame`, `MasGame`, `BottomNav`, `ThemeToggle`.

## Definición de "terminado"
1. Las 4 pantallas de `student_portal.html` se ven como este diseño (ambos temas).
2. Todos los datos vienen de `window.PERIPLO` / Firestore — **cero demo hardcodeado**.
3. Solo usa el `buildSoloMissions` / catálogo real; el flujo mapa→mundo→misión funciona.
4. Agenda lee la colección `schedule` real (lógica de match ya existente).
5. El toggle de tema en Más persiste y repinta todo. Solo se mantiene en su modo espacial.
6. Auth, signOut, `onSnapshot` y demás lógica de Firebase quedan **intactos**.
